import { useState, useRef, useEffect } from "react";
import { TrendingUp, TrendingDown, BarChart3, Clock, Users, ChevronDown, ChevronUp, X, Search, Star, Bell, Settings, Menu, Sparkles, Pencil, Eraser, Type, Move, Target, Layers, Grid, ZoomIn, ZoomOut, RotateCcw, Download, Share2, Play, Pause, AlertTriangle, Check, Info } from "lucide-react";
import { InsightsPanel } from "./components/InsightsPanel";
import { VerdictCard } from "./components/VerdictCard";
import { PeerComparison } from "./components/PeerComparison";
import { MarketIndices } from "./components/MarketIndices";
import { Watchlist } from "./components/Watchlist";
import { IndicatorsPanel } from "./components/IndicatorsPanel";
import { AlertSystem } from "./components/AlertSystem";
import { ScreenerPanel } from "./components/ScreenerPanel";
import { OrderPanel } from "./components/OrderPanel";

export type ToolType = 
  | "cursor" | "crosshair" | "line" | "trendline" | "horizontal" | "vertical"
  | "parallel" | "fibonacci" | "gann" | "andrews" | "rectangle" | "circle"
  | "text" | "brush" | "eraser" | "measure" | "freehand";

export type Drawing = {
  id: string;
  type: ToolType;
  points: { x: number; y: number }[];
  color: string;
  lineWidth: number;
};

export type Indicator = {
  id: string;
  name: string;
  type: "overlay" | "oscillator";
  visible: boolean;
  settings: Record<string, unknown>;
};

export type WatchlistStock = {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
};

export type Alert = {
  id: string;
  symbol: string;
  condition: "above" | "below" | "crosses_up" | "crosses_down";
  price: number;
  active: boolean;
  triggered: boolean;
};

const stocks = [
  { symbol: "RELIANCE", name: "Reliance Industries", price: 2425.50, change: 2.35, sector: "Energy" },
  { symbol: "TATA", name: "Tata Motors", price: 678.90, change: -1.25, sector: "Auto" },
  { symbol: "INFY", name: "Infosys", price: 1456.75, change: 1.85, sector: "IT" },
  { symbol: "HDFC", name: "HDFC Bank", price: 1623.40, change: 0.75, sector: "Banking" },
  { symbol: "TCS", name: "TCS", price: 3589.20, change: -0.45, sector: "IT" },
  { symbol: "ICICI", name: "ICICI Bank", price: 1052.30, change: 1.20, sector: "Banking" },
  { symbol: "SBIN", name: "State Bank of India", price: 625.80, change: 2.10, sector: "Banking" },
  { symbol: "WIPRO", name: "Wipro", price: 452.60, change: -0.80, sector: "IT" },
];

const tools: { id: ToolType; name: string; icon: React.ReactNode; category: string }[] = [
  { id: "cursor", name: "Cursor", icon: <Move className="w-4 h-4" />, category: "Basic" },
  { id: "crosshair", name: "Crosshair", icon: <Target className="w-4 h-4" />, category: "Basic" },
  { id: "line", name: "Trend Line", icon: <TrendingUp className="w-4 h-4" />, category: "Lines" },
  { id: "trendline", name: "Trendline", icon: <TrendingDown className="w-4 h-4" />, category: "Lines" },
  { id: "horizontal", name: "Horizontal", icon: <ChevronDown className="w-4 h-4" />, category: "Lines" },
  { id: "vertical", name: "Vertical", icon: <ChevronUp className="w-4 h-4" />, category: "Lines" },
  { id: "parallel", name: "Parallel Channel", icon: <Layers className="w-4 h-4" />, category: "Channels" },
  { id: "fibonacci", name: "Fibonacci", icon: <Grid className="w-4 h-4" />, category: "Advanced" },
  { id: "gann", name: "Gann Fan", icon: <Grid className="w-4 h-4" />, category: "Advanced" },
  { id: "andrews", name: "Andrews Pitchfork", icon: <Grid className="w-4 h-4" />, category: "Advanced" },
  { id: "rectangle", name: "Rectangle", icon: <BarChart3 className="w-4 h-4" />, category: "Shapes" },
  { id: "circle", name: "Circle", icon: <Target className="w-4 h-4" />, category: "Shapes" },
  { id: "text", name: "Text", icon: <Type className="w-4 h-4" />, category: "Annotation" },
  { id: "brush", name: "Brush", icon: <Pencil className="w-4 h-4" />, category: "Annotation" },
  { id: "freehand", name: "Freehand", icon: <Pencil className="w-4 h-4" />, category: "Annotation" },
  { id: "eraser", name: "Eraser", icon: <Eraser className="w-4 h-4" />, category: "Tools" },
  { id: "measure", name: "Measure", icon: <Grid className="w-4 h-4" />, category: "Tools" },
];

const colors = ["#22c55e", "#ef4444", "#f59e0b", "#3b82f6", "#8b5cf6", "#ec4899", "#14b8a6", "#f97316"];

export default function App() {
  const [selectedStock, setSelectedStock] = useState("RELIANCE");
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [activeTool, setActiveTool] = useState<ToolType>("cursor");
  const [activeColor, setActiveColor] = useState("#22c55e");
  const [drawings, setDrawings] = useState<Drawing[]>([]);
  const [indicators, setIndicators] = useState<Indicator[]>([]);
  const [watchlist, setWatchlist] = useState<WatchlistStock[]>([
    { symbol: "RELIANCE", name: "Reliance", price: 2425.50, change: 57.25, changePercent: 2.35, volume: 12500000 },
    { symbol: "INFY", name: "Infosys", price: 1456.75, change: 26.50, changePercent: 1.85, volume: 8500000 },
  ]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [timeframe, setTimeframe] = useState("1D");
  const [chartType, setChartType] = useState<"candle" | "line" | "area" | "heikinashi" | "renko" | "kagi">("candle");
  const [promptText, setPromptText] = useState("");
  const [generatedPrompt, setGeneratedPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [showPromptResult, setShowPromptResult] = useState(false);
  const [promptResult, setPromptResult] = useState<{
    pattern: string;
    support: number;
    resistance: number;
    trend: string;
    signal: string;
    indicators: string[];
  } | null>(null);
  
  const chartRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [ohlcData, setOhlcData] = useState<{ time: string; open: number; high: number; low: number; close: number; volume: number }[]>([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentPoints, setCurrentPoints] = useState<{ x: number; y: number }[]>([]);

  // Generate OHLC data
  useEffect(() => {
    const data = [];
    let open = 2400;
    const now = new Date();
    
    for (let i = 200; i >= 0; i--) {
      const date = new Date(now);
      date.setDate(date.getDate() - i);
      
      const volatility = 0.02;
      const change = (Math.random() - 0.5) * 2 * volatility * open;
      const close = open + change;
      const high = Math.max(open, close) + Math.random() * volatility * open;
      const low = Math.min(open, close) - Math.random() * volatility * open;
      
      data.push({
        time: date.toISOString().split('T')[0],
        open: parseFloat(open.toFixed(2)),
        high: parseFloat(high.toFixed(2)),
        low: parseFloat(low.toFixed(2)),
        close: parseFloat(close.toFixed(2)),
        volume: Math.floor(Math.random() * 10000000 + 5000000),
      });
      
      open = close;
    }
    
    setOhlcData(data);
  }, [selectedStock]);

  // Draw chart
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = chartRef.current;
    if (!canvas || !container || ohlcData.length === 0) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = container.getBoundingClientRect();
    canvas.width = rect.width;
    canvas.height = rect.height;

    const width = canvas.width;
    const height = canvas.height;
    const padding = { top: 20, right: 70, bottom: 60, left: 10 };

    // Clear
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, width, height);

    // Grid
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    
    for (let i = 0; i <= 5; i++) {
      const y = padding.top + (height - padding.top - padding.bottom) * i / 5;
      ctx.beginPath();
      ctx.moveTo(padding.left, y);
      ctx.lineTo(width - padding.right, y);
      ctx.stroke();
    }

    // Price range
    const prices = ohlcData.map(d => d.high).concat(ohlcData.map(d => d.low));
    const minPrice = Math.min(...prices);
    const maxPrice = Math.max(...prices);
    const priceRange = maxPrice - minPrice;

    const chartWidth = width - padding.left - padding.right;
    const chartHeight = height - padding.top - padding.bottom - 60;
    const candleWidth = (chartWidth / ohlcData.length) * 0.8;

    // Draw candles
    ohlcData.forEach((candle, i) => {
      const x = padding.left + (i * chartWidth / ohlcData.length) + candleWidth / 2;
      const isGreen = candle.close >= candle.open;
      
      const yOpen = padding.top + ((maxPrice - candle.open) / priceRange) * chartHeight;
      const yClose = padding.top + ((maxPrice - candle.close) / priceRange) * chartHeight;
      const yHigh = padding.top + ((maxPrice - candle.high) / priceRange) * chartHeight;
      const yLow = padding.top + ((maxPrice - candle.low) / priceRange) * chartHeight;

      // Wick
      ctx.strokeStyle = isGreen ? '#22c55e' : '#ef4444';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x, yHigh);
      ctx.lineTo(x, yLow);
      ctx.stroke();

      // Body
      ctx.fillStyle = isGreen ? '#22c55e' : '#ef4444';
      const bodyTop = Math.min(yOpen, yClose);
      const bodyHeight = Math.max(Math.abs(yClose - yOpen), 1);
      ctx.fillRect(x - candleWidth / 2, bodyTop, candleWidth, bodyHeight);
    });

    // Draw volume bars
    const maxVolume = Math.max(...ohlcData.map(d => d.volume));
    const volumeHeight = 50;
    
    ohlcData.forEach((candle, i) => {
      const x = padding.left + (i * chartWidth / ohlcData.length) + candleWidth / 2;
      const volH = (candle.volume / maxVolume) * volumeHeight;
      const isGreen = candle.close >= candle.open;
      
      ctx.fillStyle = isGreen ? 'rgba(34, 197, 94, 0.3)' : 'rgba(239, 68, 68, 0.3)';
      ctx.fillRect(x - candleWidth / 2, height - padding.bottom - volH, candleWidth, volH);
    });

    // Price labels
    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'right';
    for (let i = 0; i <= 5; i++) {
      const price = maxPrice - (priceRange * i / 5);
      const y = padding.top + (chartHeight * i / 5);
      ctx.fillText(price.toFixed(2), width - 10, y + 4);
    }

    // Draw generated prompt levels if exists
    if (promptResult) {
      // Support line
      const ySupport = padding.top + ((maxPrice - promptResult.support) / priceRange) * chartHeight;
      ctx.strokeStyle = '#22c55e';
      ctx.lineWidth = 2;
      ctx.setLineDash([5, 5]);
      ctx.beginPath();
      ctx.moveTo(padding.left, ySupport);
      ctx.lineTo(width - padding.right, ySupport);
      ctx.stroke();
      ctx.setLineDash([]);
      
      ctx.fillStyle = '#22c55e';
      ctx.font = 'bold 10px sans-serif';
      ctx.fillText(`Support: ₹${promptResult.support}`, padding.left + 5, ySupport - 5);

      // Resistance line
      const yResistance = padding.top + ((maxPrice - promptResult.resistance) / priceRange) * chartHeight;
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 2;
      ctx.setLineDash([5, 5]);
      ctx.beginPath();
      ctx.moveTo(padding.left, yResistance);
      ctx.lineTo(width - padding.right, yResistance);
      ctx.stroke();
      ctx.setLineDash([]);
      
      ctx.fillStyle = '#ef4444';
      ctx.fillText(`Resistance: ₹${promptResult.resistance}`, padding.left + 5, yResistance + 15);
    }

    // Draw existing drawings
    drawings.forEach(drawing => {
      ctx.strokeStyle = drawing.color;
      ctx.lineWidth = drawing.lineWidth;
      ctx.beginPath();
      
      drawing.points.forEach((point, idx) => {
        if (idx === 0) ctx.moveTo(point.x, point.y);
        else ctx.lineTo(point.x, point.y);
      });
      
      ctx.stroke();
    });

    // Current drawing
    if (currentPoints.length > 0 && isDrawing) {
      ctx.strokeStyle = activeColor;
      ctx.lineWidth = 2;
      ctx.beginPath();
      
      currentPoints.forEach((point, idx) => {
        if (idx === 0) ctx.moveTo(point.x, point.y);
        else ctx.lineTo(point.x, point.y);
      });
      
      ctx.stroke();
    }

  }, [ohlcData, drawings, currentPoints, isDrawing, activeColor, promptResult]);

  const handleCanvasMouseDown = (e: React.MouseEvent) => {
    if (activeTool === 'cursor') return;
    
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    setIsDrawing(true);
    setCurrentPoints([{ x, y }]);
  };

  const handleCanvasMouseMove = (e: React.MouseEvent) => {
    if (!isDrawing) return;
    
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    if (activeTool === 'brush' || activeTool === 'freehand') {
      setCurrentPoints(prev => [...prev, { x, y }]);
    } else if (currentPoints.length === 1) {
      setCurrentPoints([currentPoints[0], { x, y }]);
    }
  };

  const handleCanvasMouseUp = () => {
    if (!isDrawing) return;
    
    if (currentPoints.length > 0) {
      const newDrawing: Drawing = {
        id: Date.now().toString(),
        type: activeTool,
        points: currentPoints,
        color: activeColor,
        lineWidth: 2,
      };
      setDrawings([...drawings, newDrawing]);
    }
    
    setIsDrawing(false);
    setCurrentPoints([]);
  };

  const handleGenerateFromPrompt = () => {
    if (!promptText.trim()) return;
    
    setIsGenerating(true);
    setGeneratedPrompt(promptText);
    
    // Simulate AI processing
    setTimeout(() => {
      const currentPrice = ohlcData.length > 0 ? ohlcData[ohlcData.length - 1].close : 2400;
      
      // Generate result based on prompt
      const result = {
        pattern: detectPattern(promptText),
        support: Math.round(currentPrice * 0.97),
        resistance: Math.round(currentPrice * 1.03),
        trend: promptText.toLowerCase().includes('bearish') ? 'Bearish' : 
               promptText.toLowerCase().includes('bullish') ? 'Bullish' : 'Neutral',
        signal: generateSignal(promptText),
        indicators: ['RSI: 55', 'MACD: Bullish', 'Volume: Above Avg'],
      };
      
      setPromptResult(result);
      setShowPromptResult(true);
      setIsGenerating(false);
    }, 1500);
  };

  const detectPattern = (prompt: string): string => {
    const lower = prompt.toLowerCase();
    if (lower.includes('cup')) return 'Cup and Handle';
    if (lower.includes('flag')) return 'Bullish Flag';
    if (lower.includes('triangle')) return 'Ascending Triangle';
    if (lower.includes('head')) return 'Head and Shoulders';
    if (lower.includes('double')) return 'Double Bottom';
    return 'Consolidation Pattern';
  };

  const generateSignal = (prompt: string): string => {
    const lower = prompt.toLowerCase();
    if (lower.includes('support')) return 'Buy near support zone';
    if (lower.includes('resistance')) return 'Sell near resistance';
    if (lower.includes('breakout')) return 'Wait for breakout confirmation';
    if (lower.includes('breakdown')) return 'Caution - potential breakdown';
    return 'Monitor for entry signals';
  };

  const clearDrawings = () => setDrawings([]);
  const clearPrompt = () => {
    setPromptText("");
    setGeneratedPrompt("");
    setPromptResult(null);
    setShowPromptResult(false);
  };

  const filteredStocks = stocks.filter(s => 
    s.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const currentPrice = ohlcData.length > 0 ? ohlcData[ohlcData.length - 1].close : 0;
  const previousPrice = ohlcData.length > 1 ? ohlcData[ohlcData.length - 2].close : 0;
  const priceChange = currentPrice - previousPrice;
  const isPositive = priceChange >= 0;

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700 px-4 py-2 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-indigo-400" />
            <h1 className="text-lg font-bold text-white">Insider Radar</h1>
          </div>
          <span className="text-xs text-slate-400">by <span className="text-indigo-400 font-medium">Aapka Naam</span></span>
        </div>
        
        <div className="flex items-center gap-3">
          <MarketIndices />
          <div className="flex items-center gap-1 text-xs text-slate-400">
            <Clock className="w-3 h-3" />
            <span>{new Date().toLocaleTimeString()}</span>
          </div>
        </div>
      </header>

      {/* Search Bar */}
      <div className="bg-slate-800/50 border-b border-slate-700 px-4 py-2">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search stocks, indices, patterns..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setShowSearch(true);
            }}
            onFocus={() => setShowSearch(true)}
            className="w-full py-2 pl-10 pr-4 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500"
          />
          
          {showSearch && searchQuery && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-slate-800 border border-slate-600 rounded-lg shadow-xl z-50 max-h-64 overflow-y-auto">
              {filteredStocks.map((stock) => (
                <button
                  key={stock.symbol}
                  onClick={() => {
                    setSelectedStock(stock.symbol);
                    setSearchQuery("");
                    setShowSearch(false);
                    setPromptResult(null);
                  }}
                  className="w-full px-4 py-2 flex items-center justify-between hover:bg-slate-700"
                >
                  <div className="flex items-center gap-3">
                    <span className="font-medium text-white">{stock.symbol}</span>
                    <span className="text-xs text-slate-400">{stock.name}</span>
                  </div>
                  <span className={stock.change >= 0 ? "text-green-400 text-sm" : "text-red-400 text-sm"}>
                    {stock.change >= 0 ? '+' : ''}{stock.change}%
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar - Tools */}
        <div className="w-16 bg-slate-800 border-r border-slate-700 flex flex-col overflow-y-auto">
          <div className="p-1">
            {tools.map((tool) => (
              <button
                key={tool.id}
                onClick={() => setActiveTool(tool.id)}
                className={`w-full aspect-square flex items-center justify-center rounded transition-colors ${
                  activeTool === tool.id
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-400 hover:bg-slate-700 hover:text-white'
                }`}
                title={tool.name}
              >
                {tool.icon}
              </button>
            ))}
          </div>
          
          <div className="mt-auto p-2 border-t border-slate-700">
            <div className="grid grid-cols-2 gap-1">
              {colors.map((color) => (
                <button
                  key={color}
                  onClick={() => setActiveColor(color)}
                  className={`w-5 h-5 rounded-full border-2 ${
                    activeColor === color ? 'border-white' : 'border-transparent'
                  }`}
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
            
            <button
              onClick={clearDrawings}
              className="w-full mt-2 p-1.5 bg-slate-700 rounded text-slate-400 hover:text-white text-xs"
            >
              <RotateCcw className="w-4 h-4 mx-auto" />
            </button>
          </div>
        </div>

        {/* Chart Area */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Chart Header */}
          <div className="bg-slate-800 border-b border-slate-700 px-4 py-2 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold text-white">{selectedStock}</h2>
                  <span className="text-xs text-slate-400 bg-slate-700 px-2 py-0.5 rounded">NIFTY 50</span>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <span className={`text-xl font-bold ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
                  ₹{currentPrice.toFixed(2)}
                </span>
                <span className={`text-sm ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
                  {isPositive ? '+' : ''}{priceChange.toFixed(2)}
                </span>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              {["1m", "5m", "15m", "30m", "1H", "1D", "1W"].map((tf) => (
                <button
                  key={tf}
                  onClick={() => setTimeframe(tf)}
                  className={`px-2 py-1 text-xs font-medium rounded ${
                    timeframe === tf ? 'bg-indigo-600 text-white' : 'bg-slate-700 text-slate-400'
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>
          </div>

          {/* Chart Canvas */}
          <div ref={chartRef} className="flex-1 relative bg-slate-900" style={{ minHeight: '400px' }}>
            <canvas
              ref={canvasRef}
              className="absolute inset-0 w-full h-full cursor-crosshair"
              onMouseDown={handleCanvasMouseDown}
              onMouseMove={handleCanvasMouseMove}
              onMouseUp={handleCanvasMouseUp}
              onMouseLeave={handleCanvasMouseUp}
            />
            
            {activeTool !== 'cursor' && (
              <div className="absolute top-2 left-2 px-2 py-1 bg-indigo-600 rounded text-xs text-white flex items-center gap-1">
                <span className="capitalize">{activeTool}</span>
                <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
              </div>
            )}
            
            {promptResult && (
              <div className="absolute top-2 right-2 bg-slate-800 border border-indigo-500 rounded-lg p-3 w-64">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-indigo-400">AI Analysis</span>
                  <button onClick={clearPrompt} className="text-slate-400 hover:text-white">
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <div className="space-y-1 text-xs">
                  <p className="text-slate-300"><span className="text-slate-500">Pattern:</span> {promptResult.pattern}</p>
                  <p className="text-slate-300"><span className="text-slate-500">Trend:</span> {promptResult.trend}</p>
                  <p className="text-green-400"><span className="text-slate-500">Support:</span> ₹{promptResult.support}</p>
                  <p className="text-red-400"><span className="text-slate-500">Resistance:</span> ₹{promptResult.resistance}</p>
                  <p className="text-amber-400"><span className="text-slate-500">Signal:</span> {promptResult.signal}</p>
                </div>
              </div>
            )}
          </div>

          {/* Generate from Prompt */}
          <div className="p-3 bg-slate-800 border-t border-slate-700">
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <Sparkles className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-indigo-400" />
                <input
                  type="text"
                  placeholder="Describe pattern: 'Show support at 2400 with resistance at 2500' or 'Bullish flag pattern'"
                  value={promptText}
                  onChange={(e) => setPromptText(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleGenerateFromPrompt()}
                  className="w-full py-2 pl-10 pr-4 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500"
                />
              </div>
              <button
                onClick={handleGenerateFromPrompt}
                disabled={isGenerating || !promptText.trim()}
                className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg font-medium disabled:opacity-50 flex items-center gap-2"
              >
                {isGenerating ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    Generate
                  </>
                )}
              </button>
              {promptResult && (
                <button
                  onClick={clearPrompt}
                  className="px-3 py-2 bg-slate-700 text-slate-300 rounded-lg hover:bg-slate-600"
                >
                  Clear
                </button>
              )}
            </div>
            {generatedPrompt && !promptResult && (
              <p className="text-xs text-slate-400 mt-2">
                Analyzing: "{generatedPrompt}"
              </p>
            )}
          </div>
        </div>

        {/* Right Sidebar */}
        <div className="w-80 bg-slate-800 border-l border-slate-700 flex flex-col overflow-y-auto">
          <InsightsPanel stock={selectedStock} />
          <VerdictCard stock={selectedStock} />
          <PeerComparison stock={selectedStock} />
        </div>
      </div>
    </div>
  );
}